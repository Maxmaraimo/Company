var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.maxHeight){
            panel.style.maxHeight = null;
        } else {
            panel.style.maxHeight = panel.scrollHeight + "px";
        }
    });
}

const btnNumlike = document.querySelectorAll('.section-product-page-top-block');
const tablike = document.querySelectorAll('.section-product-page-content')

btnNumlike.forEach(function (item){
    item.addEventListener('click', function (){
        btnNumlike.forEach(function (i){
            i.classList.remove('section-product-page-top-block-active')
        })

        item.classList.add('section-product-page-top-block-active')

        let tubIDlike = item.getAttribute('data-tab');
        let tabActivelike = document.querySelector(tubIDlike);

        tablike.forEach(function (item){
            item.classList.remove('section-product-page-content-active')
        })
        tabActivelike.classList.add('section-product-page-content-active')

    })
})